import { LayoutDashboard, ClipboardList, Calendar, Sparkles, MessageCircle, BrainCircuit, BookOpen, LogOut, Sparkles as SparklesIcon, HelpCircle, Sun, Moon } from "lucide-react";
import { NavLink } from "@/components/NavLink";
import { useLocation } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useTheme } from "next-themes";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";

const items = [
  { title: "Dashboard", url: "/dashboard", icon: LayoutDashboard },
  { title: "Assignments", url: "/assignments", icon: ClipboardList },
  { title: "Timetable", url: "/timetable", icon: Calendar },
  { title: "Events", url: "/events", icon: Sparkles },
  { title: "AI Chat", url: "/chat", icon: MessageCircle },
  { title: "AI Quiz", url: "/quiz", icon: BrainCircuit },
  { title: "AI Notes", url: "/notes", icon: BookOpen },
  { title: "AI Explainer", url: "/explainer", icon: HelpCircle },
];

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const location = useLocation();
  const { logout } = useAuth();
  const { theme, setTheme } = useTheme();

  const handleLogout = () => {
    logout();
  };

  return (
    <Sidebar collapsible="icon" className="bg-gradient-to-b from-blue-950 via-blue-900 to-black min-h-screen shadow-xl border-r border-blue-800/50">
      <SidebarContent className="flex flex-col h-full">
        {/* Logo Section */}
        <div className="p-4 border-b border-blue-800/30">
          {!collapsed && (
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <SparklesIcon className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-lg font-bold text-white">
                StudyBuddy AI
              </h1>
            </div>
          )}
          {collapsed && (
            <div className="flex justify-center">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <SparklesIcon className="w-5 h-5 text-white" />
              </div>
            </div>
          )}
        </div>

        {/* Menu Section */}
        <SidebarGroup className="flex-1 px-4 py-6">
          {!collapsed && (
            <SidebarGroupLabel className="text-gray-400 text-xs font-semibold uppercase tracking-wider mb-4">
              Menu
            </SidebarGroupLabel>
          )}
          <SidebarGroupContent>
            <SidebarMenu className="space-y-2">
              {items.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink
                      to={item.url}
                      end={item.url === "/dashboard"}
                      className={({ isActive }) =>
                        `flex items-center px-4 py-3 rounded-xl transition-all duration-200 ${
                          isActive
                            ? "bg-blue-700 text-white shadow-lg"
                            : "text-gray-300 hover:bg-blue-800 hover:text-white"
                        }`
                      }
                    >
                      <item.icon className="mr-3 h-5 w-5 flex-shrink-0" />
                      {!collapsed && <span className="font-medium">{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Bottom Actions */}
        <SidebarGroup className="px-4 pb-6">
          <SidebarGroupContent>
            <SidebarMenu className="space-y-2">
              {/* Dark Mode Toggle */}
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                  className="flex items-center px-4 py-3 rounded-xl text-gray-300 hover:bg-blue-800 hover:text-white transition-all duration-200"
                >
                  {theme === "dark" ? (
                    <Sun className="mr-3 h-5 w-5 flex-shrink-0" />
                  ) : (
                    <Moon className="mr-3 h-5 w-5 flex-shrink-0" />
                  )}
                  {!collapsed && <span className="font-medium">{theme === "dark" ? "Light Mode" : "Dark Mode"}</span>}
                </SidebarMenuButton>
              </SidebarMenuItem>
              {/* Logout */}
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={handleLogout}
                  className="flex items-center px-4 py-3 rounded-xl text-gray-300 hover:bg-red-800 hover:text-white transition-all duration-200"
                >
                  <LogOut className="mr-3 h-5 w-5 flex-shrink-0" />
                  {!collapsed && <span className="font-medium">Logout</span>}
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
