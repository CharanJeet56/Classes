import { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { BookOpen, FileText, List, Lightbulb, Upload, Loader2 } from "lucide-react";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";
import * as pdfjsLib from "pdfjs-dist";

// Set worker source
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.mjs`;

type Action = "explain" | "summarize" | "keypoints";

interface Results {
  explain?: string;
  summarize?: string;
  keypoints?: string;
}

async function extractPdfText(file: File): Promise<string> {
  const arrayBuffer = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  const pages: string[] = [];
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    const text = content.items.map((item: any) => item.str).join(" ");
    pages.push(text);
  }
  return pages.join("\n\n");
}

export default function NotesAssistant() {
  const [notes, setNotes] = useState("");
  const [results, setResults] = useState<Results>({});
  const [loading, setLoading] = useState<Action | null>(null);
  const [fileLoading, setFileLoading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isPdf = file.type === "application/pdf" || file.name.endsWith(".pdf");
    const isText = file.name.endsWith(".txt") || file.type.startsWith("text/");

    if (!isPdf && !isText) {
      toast.error("Please upload a PDF or text file (.pdf, .txt)");
      return;
    }

    if (isPdf) {
      setFileLoading(true);
      try {
        const text = await extractPdfText(file);
        if (!text.trim()) {
          toast.error("Could not extract text from PDF. It may be scanned/image-based.");
        } else {
          setNotes(text);
          toast.success(`Extracted text from ${file.name}`);
        }
      } catch (err) {
        console.error(err);
        toast.error("Failed to read PDF file");
      }
      setFileLoading(false);
    } else {
      const reader = new FileReader();
      reader.onload = (ev) => setNotes(ev.target?.result as string || "");
      reader.readAsText(file);
    }

    // Reset input so re-uploading same file works
    e.target.value = "";
  };

  const processNotes = async (action: Action) => {
    if (!notes.trim()) { toast.error("Please enter or upload notes first"); return; }
    setLoading(action);

    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/notes`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: JSON.stringify({ notes: notes.trim(), action }),
        }
      );

      if (response.status === 429) { toast.error("Rate limit reached."); setLoading(null); return; }
      if (response.status === 402) { toast.error("AI credits exhausted."); setLoading(null); return; }
      if (!response.ok || !response.body) throw new Error("Failed");

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let content = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        let idx: number;
        while ((idx = buffer.indexOf("\n")) !== -1) {
          let line = buffer.slice(0, idx);
          buffer = buffer.slice(idx + 1);
          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (!line.startsWith("data: ")) continue;
          const jsonStr = line.slice(6).trim();
          if (jsonStr === "[DONE]") break;
          try {
            const parsed = JSON.parse(jsonStr);
            const delta = parsed.choices?.[0]?.delta?.content;
            if (delta) {
              content += delta;
              setResults(prev => ({ ...prev, [action]: content }));
            }
          } catch {}
        }
      }
    } catch (err) {
      toast.error("Failed to process notes");
      console.error(err);
    }
    setLoading(null);
  };

  const actions: { key: Action; label: string; icon: typeof Lightbulb; description: string }[] = [
    { key: "explain", label: "Explain Simply", icon: Lightbulb, description: "Get a simple, easy-to-understand explanation" },
    { key: "summarize", label: "Generate Summary", icon: FileText, description: "Get a concise summary of your notes" },
    { key: "keypoints", label: "Key Points", icon: List, description: "Extract important bullet points" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
          <BookOpen className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">AI Notes Assistant</h1>
          <p className="text-sm text-muted-foreground">Paste notes or upload a PDF/text file to get AI-powered insights</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Your Study Notes</CardTitle>
          <CardDescription>Paste your notes below or upload a PDF / text file</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Paste your study notes here..."
            className="min-h-[200px] resize-y"
          />
          <div className="flex flex-wrap gap-2">
            <input ref={fileRef} type="file" accept=".pdf,.txt,text/*,application/pdf" className="hidden" onChange={handleFileUpload} />
            <Button variant="outline" onClick={() => fileRef.current?.click()} disabled={fileLoading}>
              {fileLoading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Upload className="h-4 w-4 mr-2" />}
              {fileLoading ? "Extracting PDF..." : "Upload PDF / Text File"}
            </Button>
            {notes && (
              <Button variant="ghost" size="sm" onClick={() => { setNotes(""); setResults({}); }}>
                Clear
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {actions.map(({ key, label, icon: Icon, description }) => (
          <Card key={key} className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => !loading && processNotes(key)}>
            <CardContent className="p-5 flex flex-col items-center text-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                {loading === key ? <Loader2 className="h-5 w-5 text-primary animate-spin" /> : <Icon className="h-5 w-5 text-primary" />}
              </div>
              <div>
                <p className="font-semibold text-sm">{label}</p>
                <p className="text-xs text-muted-foreground mt-1">{description}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {(results.summarize || results.explain || results.keypoints) && (
        <div className="space-y-4">
          {results.summarize && (
            <Card>
              <CardHeader><CardTitle className="text-lg flex items-center gap-2"><FileText className="h-5 w-5 text-primary" /> Summary</CardTitle></CardHeader>
              <CardContent>
                <div className="prose prose-sm dark:prose-invert max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0">
                  <ReactMarkdown>{results.summarize}</ReactMarkdown>
                </div>
              </CardContent>
            </Card>
          )}
          {results.explain && (
            <Card>
              <CardHeader><CardTitle className="text-lg flex items-center gap-2"><Lightbulb className="h-5 w-5 text-primary" /> Simple Explanation</CardTitle></CardHeader>
              <CardContent>
                <div className="prose prose-sm dark:prose-invert max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0">
                  <ReactMarkdown>{results.explain}</ReactMarkdown>
                </div>
              </CardContent>
            </Card>
          )}
          {results.keypoints && (
            <Card>
              <CardHeader><CardTitle className="text-lg flex items-center gap-2"><List className="h-5 w-5 text-primary" /> Key Points</CardTitle></CardHeader>
              <CardContent>
                <div className="prose prose-sm dark:prose-invert max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0">
                  <ReactMarkdown>{results.keypoints}</ReactMarkdown>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
