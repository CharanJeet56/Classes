import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ClipboardList, Calendar, Sparkles, MessageCircle, CheckCircle2, Bell, AlertTriangle, PartyPopper } from "lucide-react";
import { Link } from "react-router-dom";
import { useAssignments } from "@/hooks/useAssignments";
import { useEvents } from "@/hooks/useEvents";
import { differenceInDays, format, isTomorrow, isToday } from "date-fns";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";

export default function Dashboard() {
  const { assignments, isLoading: loadingAssignments } = useAssignments();
  const { events, isLoading: loadingEvents } = useEvents();

  const active = assignments.filter((a) => !a.completed);
  const upcoming = active
    .filter((a) => new Date(a.deadline) >= new Date())
    .sort((a, b) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime())
    .slice(0, 3);

  const upcomingEvents = events.slice(0, 3);

  const dueTomorrow = active.filter((a) => isTomorrow(new Date(a.deadline)));
  const dueToday = active.filter((a) => isToday(new Date(a.deadline)));
  const soonEvents = events.filter((e) => {
    const d = differenceInDays(new Date(e.date), new Date());
    return d >= 0 && d <= 2;
  });

  const notifications = [
    ...dueToday.map((a) => ({ type: "urgent" as const, text: `"${a.title}" is due today!` })),
    ...dueTomorrow.map((a) => ({ type: "warning" as const, text: `"${a.title}" is due tomorrow` })),
    ...soonEvents.map((e) => ({ type: "event" as const, text: `"${e.title}" — ${format(new Date(e.date), "MMM dd")}` })),
  ];

  const stats = [
    { label: "Active Assignments", value: active.length, icon: ClipboardList, color: "text-primary" },
    { label: "Completed", value: assignments.filter(a => a.completed).length, icon: CheckCircle2, color: "text-success" },
    { label: "Upcoming Events", value: events.length, icon: Sparkles, color: "text-accent" },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">Welcome to StudyBuddy AI! 👋</h1>
        <p className="text-gray-600">Your smart student assistant – here's your overview</p>
      </div>

      {notifications.length > 0 && (
        <Card className="bg-gradient-to-br from-red-50 to-orange-50 border-red-100 shadow-md">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2 text-red-700">
              <Bell className="h-5 w-5" /> Important Notifications
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {notifications.map((n, i) => {
              const bgColorClass = n.type === "urgent" ? "bg-red-100 text-red-800" : n.type === "warning" ? "bg-yellow-100 text-yellow-800" : "bg-green-100 text-green-800";
              return (
                <div key={i} className={`flex items-start gap-3 p-3 rounded-lg ${bgColorClass}`}>
                  {n.type === "urgent" ? <AlertTriangle className="h-5 w-5 mt-0.5 flex-shrink-0" /> : n.type === "warning" ? <ClipboardList className="h-5 w-5 mt-0.5 flex-shrink-0" /> : <PartyPopper className="h-5 w-5 mt-0.5 flex-shrink-0" />}
                  <span className="text-sm font-medium">{n.text}</span>
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        {stats.map((s) => (
          <Card key={s.label} className="bg-white/80 backdrop-blur-sm hover:shadow-lg transition-all border-0">
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-gradient-to-br from-blue-100 to-purple-100 rounded-lg">
                  <s.icon className={`h-6 w-6 ${s.color}`} />
                </div>
                <div>
                  <p className="text-2xl font-bold">{loadingAssignments || loadingEvents ? "–" : s.value}</p>
                  <p className="text-sm text-gray-600">{s.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
        <Link to="/timetable">
          <Card className="cursor-pointer hover:shadow-lg transition-all bg-white/80 backdrop-blur-sm border-0 h-full">
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-gradient-to-br from-blue-100 to-purple-100 rounded-lg">
                  <Calendar className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">Timetable</p>
                  <p className="text-xs text-gray-600">Plan your schedule</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </Link>
        <Link to="/chat">
          <Card className="cursor-pointer hover:shadow-lg transition-all bg-white/80 backdrop-blur-sm border-0 h-full">
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-gradient-to-br from-blue-100 to-purple-100 rounded-lg">
                  <MessageCircle className="h-6 w-6 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">AI Assistant</p>
                  <p className="text-xs text-gray-600">Ask anything</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle className="text-lg">Upcoming Deadlines</CardTitle></CardHeader>
          <CardContent>
            {loadingAssignments ? (
              <p className="text-muted-foreground text-sm">Loading...</p>
            ) : upcoming.length === 0 ? (
              <p className="text-muted-foreground text-sm">No upcoming deadlines. <Link to="/assignments" className="text-primary underline">Add one</Link></p>
            ) : (
              <div className="space-y-3">
                {upcoming.map((a) => {
                  const days = differenceInDays(new Date(a.deadline), new Date());
                  return (
                    <div key={a.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary">
                      <div>
                        <p className="font-medium text-sm">{a.title}</p>
                        <p className="text-xs text-muted-foreground">{a.subject}</p>
                      </div>
                      <div className="text-right">
                        <p className={`text-sm font-semibold ${days <= 2 ? "text-destructive" : days <= 5 ? "text-warning" : "text-success"}`}>
                          {days === 0 ? "Today!" : `${days} day${days !== 1 ? "s" : ""} left`}
                        </p>
                        <p className="text-xs text-muted-foreground">{format(new Date(a.deadline), "MMM dd")}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-lg">Campus Events</CardTitle></CardHeader>
          <CardContent>
            {loadingEvents ? (
              <p className="text-muted-foreground text-sm">Loading...</p>
            ) : upcomingEvents.length === 0 ? (
              <p className="text-muted-foreground text-sm">No events. <Link to="/events" className="text-primary underline">Browse events</Link></p>
            ) : (
              <div className="space-y-3">
                {upcomingEvents.map((e) => (
                  <div key={e.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary">
                    <div>
                      <p className="font-medium text-sm">{e.title}</p>
                      <p className="text-xs text-muted-foreground">{e.category}</p>
                    </div>
                    <p className="text-xs text-muted-foreground">{format(new Date(e.date), "MMM dd")}</p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
