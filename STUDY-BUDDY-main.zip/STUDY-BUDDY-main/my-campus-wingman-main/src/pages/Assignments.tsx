import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAssignments } from "@/hooks/useAssignments";
import { differenceInDays, format } from "date-fns";
import { Plus, Trash2, Check, AlertTriangle } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Assignments() {
  const { assignments, isLoading, addAssignment, removeAssignment, toggleComplete, clearAll } = useAssignments();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ subject: "", title: "", deadline: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.subject || !form.title || !form.deadline) return;
    addAssignment(form);
    setForm({ subject: "", title: "", deadline: "" });
    setOpen(false);
  };

  const active = assignments.filter((a) => !a.completed);
  const completed = assignments.filter((a) => a.completed);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Assignment Manager</h1>
          <p className="text-muted-foreground">Track your deadlines</p>
        </div>
        <div className="flex gap-2">
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" size="sm" disabled={assignments.length === 0}>
                <Trash2 className="h-4 w-4 mr-2" />Clear All
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Clear all assignments?</AlertDialogTitle>
                <AlertDialogDescription>This will permanently delete all assignments. This action cannot be undone.</AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={clearAll}>Delete All</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button><Plus className="h-4 w-4 mr-2" />Add Assignment</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>New Assignment</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label>Subject</Label>
                  <Input value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} placeholder="e.g. Computer Science" />
                </div>
                <div>
                  <Label>Title</Label>
                  <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="e.g. Lab Report #3" />
                </div>
                <div>
                  <Label>Deadline</Label>
                  <Input type="date" value={form.deadline} onChange={(e) => setForm({ ...form, deadline: e.target.value })} />
                </div>
                <Button type="submit" className="w-full">Save Assignment</Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {isLoading ? (
        <Card><CardContent className="py-12 text-center"><p className="text-muted-foreground">Loading...</p></CardContent></Card>
      ) : (
        <Tabs defaultValue="active">
          <TabsList>
            <TabsTrigger value="active">Active ({active.length})</TabsTrigger>
            <TabsTrigger value="completed">Completed ({completed.length})</TabsTrigger>
          </TabsList>
          <TabsContent value="active" className="space-y-3 mt-4">
            {active.length === 0 ? (
              <Card><CardContent className="py-12 text-center"><p className="text-muted-foreground">No active assignments!</p></CardContent></Card>
            ) : (
              active.map((a) => {
                const days = differenceInDays(new Date(a.deadline), new Date());
                const isPast = days < 0;
                return (
                  <Card key={a.id} className={`transition-all ${isPast ? "border-destructive/50 opacity-75" : ""}`}>
                    <CardContent className="py-4 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Button variant="outline" size="icon" className="h-8 w-8 rounded-full shrink-0" onClick={() => toggleComplete(a.id, true)}>
                          <Check className="h-4 w-4" />
                        </Button>
                        <div>
                          <p className="font-medium">{a.title}</p>
                          <p className="text-sm text-muted-foreground">{a.subject} · {format(new Date(a.deadline), "MMM dd, yyyy")}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        {isPast && <AlertTriangle className="h-4 w-4 text-destructive" />}
                        <span className={`text-sm font-semibold ${isPast ? "text-destructive" : days <= 2 ? "text-destructive" : days <= 5 ? "text-warning" : "text-success"}`}>
                          {isPast ? "Past due" : days === 0 ? "Due today" : `${days}d left`}
                        </span>
                        <Button variant="ghost" size="icon" onClick={() => removeAssignment(a.id)}>
                          <Trash2 className="h-4 w-4 text-muted-foreground" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            )}
          </TabsContent>
          <TabsContent value="completed" className="space-y-3 mt-4">
            {completed.length === 0 ? (
              <Card><CardContent className="py-12 text-center"><p className="text-muted-foreground">No completed assignments yet.</p></CardContent></Card>
            ) : (
              completed.map((a) => (
                <Card key={a.id} className="opacity-60">
                  <CardContent className="py-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Button variant="outline" size="icon" className="h-8 w-8 rounded-full shrink-0 bg-primary/10" onClick={() => toggleComplete(a.id, false)}>
                        <Check className="h-4 w-4 text-primary" />
                      </Button>
                      <div>
                        <p className="font-medium line-through">{a.title}</p>
                        <p className="text-sm text-muted-foreground">{a.subject}</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => removeAssignment(a.id)}>
                      <Trash2 className="h-4 w-4 text-muted-foreground" />
                    </Button>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}
