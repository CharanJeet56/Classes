import { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Code2, Sparkles, Loader2, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";

export default function AIExplainer() {
  const [code, setCode] = useState("");
  const [explanation, setExplanation] = useState("");
  const [loading, setLoading] = useState(false);
  const outputRef = useRef<HTMLDivElement>(null);

  const explain = async () => {
    if (!code.trim()) {
      toast.error("Please paste some code first");
      return;
    }
    setLoading(true);
    setExplanation("");

    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/explainer`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: JSON.stringify({ code: code.trim() }),
        }
      );

      if (response.status === 429) { toast.error("Rate limit reached. Please wait a moment."); setLoading(false); return; }
      if (response.status === 402) { toast.error("AI credits exhausted."); setLoading(false); return; }
      if (!response.ok || !response.body) throw new Error("Failed to get response");

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let content = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        let newlineIndex: number;
        while ((newlineIndex = buffer.indexOf("\n")) !== -1) {
          let line = buffer.slice(0, newlineIndex);
          buffer = buffer.slice(newlineIndex + 1);
          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (!line.startsWith("data: ")) continue;
          const jsonStr = line.slice(6).trim();
          if (jsonStr === "[DONE]") break;
          try {
            const parsed = JSON.parse(jsonStr);
            const delta = parsed.choices?.[0]?.delta?.content;
            if (delta) {
              content += delta;
              setExplanation(content);
              outputRef.current?.scrollTo({ top: outputRef.current.scrollHeight, behavior: "smooth" });
            }
          } catch {}
        }
      }
    } catch (err) {
      toast.error("Failed to generate explanation");
      console.error(err);
    }
    setLoading(false);
  };

  const reset = () => {
    setCode("");
    setExplanation("");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
          <Code2 className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">AI Code Explainer</h1>
          <p className="text-sm text-muted-foreground">Paste any code and get a simple, clear explanation</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Code2 className="h-4 w-4 text-primary" /> Your Code
            </CardTitle>
            <CardDescription>Paste the code you want explained below</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder={`# Paste any code here, e.g.:\ndef fibonacci(n):\n    if n <= 1:\n        return n\n    return fibonacci(n-1) + fibonacci(n-2)`}
              className="min-h-[300px] font-mono text-sm resize-y"
            />
            <div className="flex gap-2">
              <Button
                onClick={explain}
                disabled={loading || !code.trim()}
                className="flex-1 sm:flex-none"
              >
                {loading ? (
                  <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Explaining...</>
                ) : (
                  <><Sparkles className="h-4 w-4 mr-2" /> Explain Code</>
                )}
              </Button>
              {(code || explanation) && (
                <Button variant="outline" onClick={reset} size="icon">
                  <RotateCcw className="h-4 w-4" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Output */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" /> Explanation
            </CardTitle>
            <CardDescription>AI-generated breakdown of your code</CardDescription>
          </CardHeader>
          <CardContent>
            {!explanation && !loading ? (
              <div className="min-h-[300px] flex flex-col items-center justify-center text-center gap-3 text-muted-foreground">
                <Code2 className="h-12 w-12 opacity-20" />
                <p className="text-sm">Your explanation will appear here.<br />Paste code and click <strong>Explain Code</strong>.</p>
              </div>
            ) : (
              <div
                ref={outputRef}
                className="min-h-[300px] max-h-[500px] overflow-y-auto"
              >
                <div className="prose prose-sm dark:prose-invert max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0 [&_p]:mb-3 [&_ul]:mb-3 [&_ol]:mb-3 [&_h1]:text-base [&_h1]:font-bold [&_h2]:text-sm [&_h2]:font-semibold [&_h3]:text-sm [&_h3]:font-medium [&_li]:mb-1 [&_code]:bg-muted [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:rounded [&_code]:text-xs [&_pre]:bg-muted [&_pre]:p-3 [&_pre]:rounded-lg [&_pre]:overflow-x-auto">
                  <ReactMarkdown>{explanation || "..."}</ReactMarkdown>
                </div>
                {loading && (
                  <div className="flex items-center gap-2 mt-3 text-sm text-muted-foreground">
                    <div className="flex gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-bounce [animation-delay:0ms]" />
                      <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-bounce [animation-delay:150ms]" />
                      <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-bounce [animation-delay:300ms]" />
                    </div>
                    <span>Generating...</span>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
