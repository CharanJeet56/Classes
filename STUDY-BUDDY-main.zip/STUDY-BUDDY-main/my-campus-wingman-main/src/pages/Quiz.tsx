import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Loader2, Eye, EyeOff, BrainCircuit, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";

interface Question {
  question: string;
  options: { A: string; B: string; C: string; D: string };
  answer: "A" | "B" | "C" | "D";
}

export default function Quiz() {
  const [topic, setTopic] = useState("");
  const [numQuestions, setNumQuestions] = useState("5");
  const [difficulty, setDifficulty] = useState("medium");
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(false);
  const [showAnswers, setShowAnswers] = useState(false);
  const [selected, setSelected] = useState<Record<number, string>>({});

  const generate = async () => {
    if (!topic.trim()) { toast.error("Please enter a topic or study notes"); return; }
    setLoading(true);
    setQuestions([]);
    setShowAnswers(false);
    setSelected({});

    try {
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/quiz`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({ topic: topic.trim(), numQuestions: parseInt(numQuestions), difficulty }),
      });

      if (res.status === 429) { toast.error("Rate limit reached. Please wait."); setLoading(false); return; }
      if (res.status === 402) { toast.error("AI credits exhausted."); setLoading(false); return; }
      if (!res.ok) throw new Error("Failed to generate quiz");

      const data = await res.json();
      if (data.questions?.length) {
        setQuestions(data.questions);
        toast.success(`Generated ${data.questions.length} questions!`);
      } else {
        toast.error("No questions generated. Try a different topic.");
      }
    } catch {
      toast.error("Failed to generate quiz");
    }
    setLoading(false);
  };

  const score = questions.length > 0 && showAnswers
    ? questions.reduce((acc, q, i) => acc + (selected[i] === q.answer ? 1 : 0), 0)
    : null;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">AI Quiz Generator</h1>
        <p className="text-muted-foreground">Generate practice quizzes from any topic or study notes</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <BrainCircuit className="h-5 w-5 text-primary" /> Configure Quiz
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Topic or Study Notes</Label>
            <Textarea
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Enter a topic (e.g. 'Photosynthesis') or paste your study notes..."
              className="mt-1.5 min-h-[100px]"
            />
          </div>
          <div className="flex gap-4 flex-wrap">
            <div className="space-y-1.5">
              <Label>Questions</Label>
              <Select value={numQuestions} onValueChange={setNumQuestions}>
                <SelectTrigger className="w-[140px]"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">5 Questions</SelectItem>
                  <SelectItem value="10">10 Questions</SelectItem>
                  <SelectItem value="15">15 Questions</SelectItem>
                  <SelectItem value="20">20 Questions</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Difficulty</Label>
              <Select value={difficulty} onValueChange={setDifficulty}>
                <SelectTrigger className="w-[120px]"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="easy">Easy</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="hard">Hard</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <Button onClick={generate} disabled={loading || !topic.trim()} className="w-full sm:w-auto">
            {loading ? <><Loader2 className="h-4 w-4 animate-spin" /> Generating...</> : "Generate Quiz"}
          </Button>
        </CardContent>
      </Card>

      {questions.length > 0 && (
        <>
          <div className="flex items-center justify-between flex-wrap gap-2">
            <h2 className="text-lg font-semibold">Quiz ({questions.length} questions)</h2>
            <div className="flex gap-2 items-center">
              {score !== null && (
                <Badge variant={score >= questions.length * 0.7 ? "default" : "destructive"} className="text-sm">
                  Score: {score}/{questions.length}
                </Badge>
              )}
              <Button variant="outline" size="sm" onClick={() => setShowAnswers(!showAnswers)}>
                {showAnswers ? <><EyeOff className="h-4 w-4 mr-1" /> Hide Answers</> : <><Eye className="h-4 w-4 mr-1" /> Show Answers</>}
              </Button>
            </div>
          </div>

          <div className="space-y-4">
            {questions.map((q, i) => (
              <Card key={i}>
                <CardContent className="pt-6 space-y-3">
                  <p className="font-medium">
                    <span className="text-primary mr-2">Q{i + 1}.</span>
                    {q.question}
                  </p>
                  <div className="grid gap-2 sm:grid-cols-2">
                    {(["A", "B", "C", "D"] as const).map((key) => {
                      const isSelected = selected[i] === key;
                      const isCorrect = q.answer === key;
                      let variant = "outline" as "outline" | "default" | "destructive";
                      if (showAnswers && isCorrect) variant = "default";
                      else if (showAnswers && isSelected && !isCorrect) variant = "destructive";
                      else if (isSelected) variant = "secondary" as any;

                      return (
                        <Button
                          key={key}
                          variant={variant}
                          className={`justify-start text-left h-auto py-2.5 px-3 whitespace-normal ${
                            isSelected && !showAnswers ? "bg-secondary border-primary" : ""
                          }`}
                          onClick={() => !showAnswers && setSelected((p) => ({ ...p, [i]: key }))}
                          disabled={showAnswers}
                        >
                          <span className="font-semibold mr-2 shrink-0">{key}.</span>
                          <span>{q.options[key]}</span>
                          {showAnswers && isCorrect && <CheckCircle2 className="h-4 w-4 ml-auto shrink-0 text-primary-foreground" />}
                          {showAnswers && isSelected && !isCorrect && <XCircle className="h-4 w-4 ml-auto shrink-0" />}
                        </Button>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
